# risograph_style

two inks. one machine. a hundred ways for it to go slightly wrong.

Risograph printing visual grammar — the RISO GR/EZ series digital duplicator that became the indie publishing machine of the 2010s. Limited spot color palettes, halftone dot screens, ink-on-ink multiply blending, and the beautiful accidents of mechanical misregistration.

## What This Is

Technical visual grammar for risograph-style rendering — the physical ink behavior, the color system, the halftone mathematics, and the specific palette of RISO standard inks.

## Visual DNA

**RISO ink colors (standard catalogue):**
- `#FF4C00` Fluorescent Red (SO46)
- `#FFE800` Yellow (S006)
- `#00A95C` Green (S009)  
- `#0078BF` Blue (S027)
- `#FF6BB5` Fluorescent Pink (SO47)
- `#012169` Navy Blue (S019)
- `#DC4E28` Orange (S150)
- `#3D1F6D` Purple (S017)
- `#00838A` Teal (S175)
- `#8B4C2A` Brown (S053)
- `#000000` Black (S040)

**Physical ink behavior:**
- Ink is translucent: where two inks overlap they multiply, not add
- Dot gain: halftone dots are larger in ink than in artwork (5–15%)
- Ink order matters: first ink down = bottom layer; topographic color mixing
- Paper shows through: ink sits ON paper, doesn't penetrate fully — paper color is a palette element
- Ink slur: fast drum rotation causes slight directional smear at high coverage

**Halftone screens:**
- Standard: 65–85 lpi halftone
- Angle: each color at different angle to avoid moiré (45°, 75°, 105°)
- Dot: circular dot (standard), elliptical, line, cross
- AM halftone: regular grid (standard riso)
- FM halftone: random dot position, less moiré

**Color palettes (2-color combinations):**
- `RISO_CHERRY`: Fluorescent Red + Yellow = warm orange shadows
- `RISO_OCEAN`: Blue + Teal = cyan-adjacent water
- `RISO_FOREST`: Green + Brown = earthy natural
- `RISO_NIGHT`: Navy + Fluorescent Pink = party purple
- `RISO_ACID`: Fluorescent Red + Green = horrible + correct
- `RISO_PUNK`: Black + Fluorescent Pink = gig poster energy

## Aesthetic Regimes

### `TWO_COLOR_CLEAN` — Intentional 2-ink risograph
Two chosen inks. Deliberate misregistration (2–4px). Halftone at 65 lpi. Paper color (cream/white) as third color. Multiply blend in overlap zone.

### `THREE_COLOR_PUSH` — Maximum before it breaks
Three inks. Risk of moiré. Overlap creates up to 7 color zones. Registration tighter but still imperfect. Dense and rich.

### `FLUORESCENT_GLOW` — Neon risograph
Fluorescent Red + Fluorescent Pink dominant. Against cream paper. Halftone at 75 lpi. Electric and delicate simultaneously.

### `DARK_MATTER` — Black + one color
Heavy black layer. Single second ink at low density — peek-through effect. Ink-dark ground with color emerging.

### `MISREG_CHAOS` — Registration deliberately broken
Large misregistration (8–15px). Colors fight. Shadow becomes color edge. The accident is the aesthetic.

## Shader Parameters

```glsl
uniform int   u_n_inks;             // 1–3, number of RISO ink colors
uniform vec3  u_ink_1;              // first ink color
uniform vec3  u_ink_2;              // second ink color
uniform vec3  u_ink_3;              // third ink color (if n_inks=3)
uniform float u_halftone_lpi;       // 45.0–85.0
uniform float u_halftone_angle_1;   // radians, screen angle for ink 1
uniform float u_halftone_angle_2;   // screen angle for ink 2
uniform float u_misreg_1;           // vec2 pixel offset for ink 1
uniform float u_misreg_2;           // vec2 pixel offset for ink 2
uniform float u_dot_gain;           // 1.0–1.15, dot size multiplier
uniform vec3  u_paper_color;        // paper/substrate base color
uniform float u_ink_transparency;   // 0.6–0.85, ink translucency
```

## Ecosystem

Part of the [merrypranxter](https://github.com/merrypranxter) generative art pipeline.
RepoScripter2 context source. ShaderForge style module.

Use with: `zine_aesthetic`, `dither`, `damage_aesthetics`, `duotone_halftone_press`
